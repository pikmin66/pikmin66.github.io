document.addEventListener('DOMContentLoaded', () => {
    // Game state variables
    let numPlayers = 2;
    let userPlayerIndex = 0;
    let summoningPoints = [];
    let lifePoints = [];
    let gamePoints = [];
    let currentPhase = 'drawPhase';
    let playersMonsters = [];
    let playersAlive = [];
    let playerDecks = [];
    let playerHands = [];
    let discardPiles = [];
    let cardsData = [];
    let trickCount = 0;
    let maxTricks = 1;
    let tableZone = [];

    // Load card data from JSON file
    fetch('cards.json')
        .then(response => response.json())
        .then(data => {
            cardsData = data;
            init();
        })
        .catch(error => {
            console.error('Error loading card data:', error);
            alert('Error loading card data: ' + error.message);
        });

    // Initialize the game interface
    function init() {
        document.getElementById('startGame').addEventListener('click', initializeGame);
        document.getElementById('nextRound').addEventListener('click', startNextRound);
        document.getElementById('endDrawPhase').addEventListener('click', endDrawPhase);
        document.getElementById('endSummoningPhase').addEventListener('click', endSummoningPhase);
        document.getElementById('endBattlePhase').addEventListener('click', endBattlePhase);
        document.getElementById('calculateTrickResults').addEventListener('click', endTrickTakingPhase);
        document.getElementById('toggleToPlayZone').addEventListener('click', toggleToPlayZone);
        document.getElementById('toggleToGameCompanion').addEventListener('click', toggleToGameCompanion);
        initPlayZone();
    }

    function initPlayZone() {
        const handCardsContainer = document.getElementById('hand-cards');
        const tableZoneContainer = document.getElementById('table-zone');
        const playAreaContainer = document.getElementById('play-area-cards');

        if (handCardsContainer && tableZoneContainer && playAreaContainer) {
            handCardsContainer.innerHTML = '<p>Your hand will appear here.</p>';
            tableZoneContainer.innerHTML = '<p>Cards on the table will appear here.</p>';
            playAreaContainer.innerHTML = '<p>Cards you play will appear here.</p>';
        }
    }

    function initializeGame() {
        numPlayers = parseInt(document.getElementById('numPlayers').value);
        userPlayerIndex = 0;

        summoningPoints = new Array(numPlayers).fill(1000);
        lifePoints = new Array(numPlayers).fill(8000);
        gamePoints = new Array(numPlayers).fill(0);
        playersAlive = new Array(numPlayers).fill(true);

        playerDecks = [];
        playerHands = [];
        discardPiles = [];
        playersMonsters = [];

        for (let i = 0; i < numPlayers; i++) {
            let deck = [...cardsData];
            deck = shuffleArray(deck);
            playerDecks.push(deck);

            playerHands[i] = [];
            for (let j = 0; j < 6; j++) {
                let card = drawCardFromDeck(i);
                if (card) playerHands[i].push(card);
            }

            discardPiles.push([]);
            playersMonsters.push([]);
        }

        tableZone = [];
        updatePlayZone(userPlayerIndex);
        moveToNextPhase('gameSetup', 'drawPhase');
        generateDrawPhaseInputs();
        document.getElementById('playerStatsOverview').classList.remove('hidden');
    }

    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    function drawCardFromDeck(playerIndex) {
        if (playerHands[playerIndex].length >= 6) {
            return null;
        }
        if (playerDecks[playerIndex].length > 0) {
            return playerDecks[playerIndex].shift();
        } else {
            if (playerIndex === userPlayerIndex) {
                alert('No more cards in your deck!');
            }
            return null;
        }
    }

    function updatePlayZone(playerIndex = userPlayerIndex) {
        let handCardsContainer = document.getElementById('hand-cards');
        handCardsContainer.innerHTML = '';

        playerHands[playerIndex].forEach(card => {
            let cardElement = createCardElement(card, 'hand');
            handCardsContainer.appendChild(cardElement);
        });

        updateTableZone();
        setupDragAndDrop(playerIndex);
        updatePlayerStats(); // Update stats after changes in play zone
    }

    function updateTableZone() {
        let tableContainer = document.getElementById('table-zone');
        tableContainer.innerHTML = '';

        tableZone.forEach(card => {
            let cardElement = createCardElement(card, 'table');
            tableContainer.appendChild(cardElement);
        });
    }

    function createCardElement(cardData, location) {
        let cardDiv = document.createElement('div');
        cardDiv.classList.add('card');
        cardDiv.draggable = (location === 'hand');
        cardDiv.id = cardData.id;
        cardDiv.dataset.card = JSON.stringify(cardData);

        let img = document.createElement('img');
        img.src = cardData.image || 'images/placeholder.png';
        img.alt = cardData.name;
        cardDiv.appendChild(img);

        addDynamicCardStyles(cardDiv, cardData, location);

        return cardDiv;
    }

    function addDynamicCardStyles(cardDiv, cardData, location) {
        let infoDiv = document.createElement('div');
        infoDiv.classList.add('card-info');

        // Adjust styles based on phase and card type
        if (currentPhase === 'trickTakingPhase') {
            infoDiv.innerHTML = `
                <div class="info-bottom-center">
                    ${cardData.suitRank || ''}
                    <br>
                    ${'★'.repeat(cardData.stars || 0)}
                </div>
            `;
            cardDiv.style.border = cardData.type === "Taker" ? '4px solid red' : '4px solid black'; // Taker cards bold red, Trickster cards bold black
        } else {
            infoDiv.innerHTML = `
                <div class="info-bottom-center">
                    Lv.${cardData.level || 'N/A'}
                    <br>
                    ⚔${cardData.atk || 'N/A'}⛊${cardData.def || 'N/A'}
                </div>
            `;
            cardDiv.style.border = '4px solid blue'; // All other phases have bold blue outlines
        }

        cardDiv.appendChild(infoDiv);
        infoDiv.style.position = 'absolute';
        infoDiv.style.bottom = '5px';
        infoDiv.style.left = '50%';
        infoDiv.style.transform = 'translateX(-50%)';
        infoDiv.style.backgroundColor = 'rgba(255, 255, 255, 0.8)'; // Semi-transparent background
        infoDiv.style.borderRadius = '3px';
        infoDiv.style.padding = '2px';

        if (currentPhase === 'trickTakingPhase' || location === 'played') {
            infoDiv.style.position = 'absolute';
            infoDiv.style.bottom = '5px';
            infoDiv.style.right = '5px';
        }
    }

    function setupDragAndDrop(playerIndex = userPlayerIndex) {
        const handCardsContainer = document.getElementById('hand-cards');
        const tableZoneContainer = document.getElementById('table-zone');
        const playAreaContainer = document.getElementById('play-area-cards');

        if (!handCardsContainer || !tableZoneContainer || !playAreaContainer) return;

        handCardsContainer.querySelectorAll('.card').forEach(card => {
            card.addEventListener('dragstart', event => {
                event.dataTransfer.setData('text/plain', event.target.id);
                event.target.classList.add('dragging');
            });

            card.addEventListener('dragend', event => {
                event.target.classList.remove('dragging');
            });
        });

        [tableZoneContainer, playAreaContainer].forEach(zone => {
            zone.addEventListener('dragover', event => {
                event.preventDefault();
                zone.classList.add('drag-over');
            });

            zone.addEventListener('dragleave', () => {
                zone.classList.remove('drag-over');
            });

            zone.addEventListener('drop', event => {
                event.preventDefault();
                zone.classList.remove('drag-over');

                const cardId = event.dataTransfer.getData('text/plain');
                const cardElement = document.getElementById(cardId);

                if (cardElement && cardElement.parentNode === handCardsContainer) {
                    zone.appendChild(cardElement);
                    tableZone.push(JSON.parse(cardElement.dataset.card));
                }
                updatePlayerStats(); // Update stats after a card is moved
            });
        });
    }

    // Handle trick-taking phase and calculate results
    function endTrickTakingPhase() {
        if (currentPhase !== 'trickTakingPhase') return;

        // Calculate trick results here
        let trickValues = {};
        let totalStars = 0;

        tableZone.forEach(card => {
            totalStars += card.stars; // Accumulate stars from played cards
            trickValues[card.id] = card; // Store card info for potential future logic
        });

        // Display results
        let summary = '<h3>Trick Result:</h3>';
        summary += `<p>Total Stars in Trick: ${totalStars} (equivalent to ${totalStars * 100} Summoning Points)</p>`;
        document.getElementById('trickResult').innerHTML = summary;

        // Move to next phase (adjust based on winning logic)
        moveToNextPhase('trickTakingPhase', 'summoningPhase');
    }

    function endSummoningPhase() {
        if (currentPhase !== 'summoningPhase') return;

        // Summoning phase logic goes here
        moveToNextPhase('summoningPhase', 'battlePhase');
    }

    function endBattlePhase() {
        if (currentPhase !== 'battlePhase') return;

        // Battle phase logic goes here
        moveToNextPhase('battlePhase', 'endPhase');
    }

    // Start the next round
    function startNextRound() {
        tableZone = []; // Reset the table zone for the next round
        moveToNextPhase('endPhase', 'drawPhase');
        generateDrawPhaseInputs();
    }

    // Move to the next game phase
    function moveToNextPhase(fromPhase, toPhase) {
        document.getElementById(fromPhase).classList.add('hidden');
        document.getElementById(toPhase).classList.remove('hidden');
        currentPhase = toPhase;

        updatePlayerStats(); // Update stats on phase change

        if (toPhase === 'drawPhase') {
            generateDrawPhaseInputs();
        } else if (toPhase === 'summoningPhase') {
            generateSummoningInputs();
        } else if (toPhase === 'battlePhase') {
            generateBattleInputs();
        }
    }

    // Generates input for the draw phase
    function generateDrawPhaseInputs() {
        const drawInputsContainer = document.getElementById('drawPhaseInputs');
        drawInputsContainer.innerHTML = '';

        for (let i = 0; i < 2; i++) {
            let card = drawCardFromDeck(userPlayerIndex);
            if (card) {
                let cardDiv = document.createElement('div');
                cardDiv.classList.add('draw-card-info');
                cardDiv.innerHTML = `
                    <p><strong>${card.name}</strong></p>
                    <p>ATK: ${card.atk} / DEF: ${card.def}</p>
                `;
                drawInputsContainer.appendChild(cardDiv);
            }
        }
        updatePlayerStats(); // Update stats after drawing cards
    }

    // Generates input for the summoning phase
    function generateSummoningInputs() {
        const summoningInputsContainer = document.getElementById('summoningInputs');
        summoningInputsContainer.innerHTML = '';

        playerHands[userPlayerIndex].forEach(card => {
            if (card.level) { // Only show cards that can be summoned
                let cardOption = document.createElement('option');
                cardOption.value = card.id;
                cardOption.textContent = `${card.name} (Lv.${card.level})`;
                summoningInputsContainer.appendChild(cardOption);
            }
        });
    }

    // Generates input for the battle phase
    function generateBattleInputs() {
        const battleInputsContainer = document.getElementById('battleInputs');
        battleInputsContainer.innerHTML = '';

        playersMonsters[userPlayerIndex].forEach(monster => {
            let monsterDiv = document.createElement('div');
            monsterDiv.innerHTML = `
                <p>${monster.name} (ATK: ${monster.atk}, DEF: ${monster.def})</p>
            `;
            battleInputsContainer.appendChild(monsterDiv);
        });
    }

    // Toggle between Play Zone and Game Companion views
    function toggleToPlayZone() {
        document.getElementById('gameCompanion').classList.add('hidden');
        document.getElementById('playZone').classList.remove('hidden');
        updatePlayerStats(); // Update stats when switching views
    }

    function toggleToGameCompanion() {
        document.getElementById('playZone').classList.add('hidden');
        document.getElementById('gameCompanion').classList.remove('hidden');
        updatePlayerStats(); // Update stats when switching views
    }

    // Update player stats
    function updatePlayerStats() {
        let playerStatsContainer = document.getElementById('playerStats');
        playerStatsContainer.innerHTML = '';

        for (let i = 0; i < numPlayers; i++) {
            let statsDiv = document.createElement('div');
            statsDiv.classList.add('player-stats');
            statsDiv.innerHTML = `
                <h3>Player ${i + 1}</h3>
                <p><strong>Summoning Points:</strong> ${summoningPoints[i]}</p>
                <p><strong>Life Points:</strong> ${lifePoints[i]}</p>
                <p><strong>Game Points:</strong> ${gamePoints[i]}</p>
            `;
            playerStatsContainer.appendChild(statsDiv);
        }
    }
});
